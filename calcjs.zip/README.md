# calcjs
a simple javascript based calculator

## A simple calculator:
A simple calculator made in js. Feaures supports brackets. Supports history/ logs

## Lessons:
var is dead is js. 
better use let.


